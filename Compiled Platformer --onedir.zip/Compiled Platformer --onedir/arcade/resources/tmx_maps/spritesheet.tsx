<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="spritesheet" tilewidth="128" tileheight="128" tilecount="156" columns="13">
 <image source="../images/spritesheets/tiles.png" width="1664" height="1536"/>
</tileset>
